"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, Trash2, Edit } from "lucide-react"
import Link from "next/link"

interface Client {
  id: string
  name: string
  technicalKnowledge: number
  description: string
}

export default function AdminPage() {
  const [clients, setClients] = useState<Client[]>([])
  const [isEditing, setIsEditing] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    technicalKnowledge: 1,
    description: "",
  })

  // Load clients from localStorage on component mount
  useEffect(() => {
    const savedClients = localStorage.getItem("emailReviewClients")
    if (savedClients) {
      setClients(JSON.parse(savedClients))
    }
  }, [])

  // Save clients to localStorage whenever clients change
  useEffect(() => {
    localStorage.setItem("emailReviewClients", JSON.stringify(clients))
  }, [clients])

  const handleAddClient = () => {
    if (!formData.name.trim()) return

    const newClient: Client = {
      id: Date.now().toString(),
      name: formData.name,
      technicalKnowledge: formData.technicalKnowledge,
      description: formData.description,
    }

    setClients([...clients, newClient])
    setFormData({ name: "", technicalKnowledge: 1, description: "" })
  }

  const handleEditClient = (client: Client) => {
    setIsEditing(client.id)
    setFormData({
      name: client.name,
      technicalKnowledge: client.technicalKnowledge,
      description: client.description,
    })
  }

  const handleUpdateClient = () => {
    if (!formData.name.trim() || !isEditing) return

    setClients(
      clients.map((client) =>
        client.id === isEditing
          ? {
              ...client,
              name: formData.name,
              technicalKnowledge: formData.technicalKnowledge,
              description: formData.description,
            }
          : client,
      ),
    )

    setIsEditing(null)
    setFormData({ name: "", technicalKnowledge: 1, description: "" })
  }

  const handleDeleteClient = (id: string) => {
    setClients(clients.filter((client) => client.id !== id))
  }

  const handleCancelEdit = () => {
    setIsEditing(null)
    setFormData({ name: "", technicalKnowledge: 1, description: "" })
  }

  const getTechnicalLevelText = (level: number) => {
    if (level <= 2) return "Beginner"
    if (level <= 4) return "Intermediate"
    return "Advanced"
  }

  const getTechnicalLevelColor = (level: number) => {
    if (level <= 2) return "bg-red-100 text-red-800"
    if (level <= 4) return "bg-yellow-100 text-yellow-800"
    return "bg-green-100 text-green-800"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Email Review
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Client Management</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Add/Edit Client Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                {isEditing ? "Edit Client" : "Add New Client"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Client Name *</Label>
                <Input
                  id="name"
                  placeholder="Enter client name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="technicalKnowledge">Technical Knowledge Level *</Label>
                <Select
                  value={formData.technicalKnowledge.toString()}
                  onValueChange={(value) => setFormData({ ...formData, technicalKnowledge: Number.parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Beginner (No technical background)</SelectItem>
                    <SelectItem value="2">2 - Beginner (Basic computer skills)</SelectItem>
                    <SelectItem value="3">3 - Intermediate (Some technical understanding)</SelectItem>
                    <SelectItem value="4">4 - Intermediate (Good technical grasp)</SelectItem>
                    <SelectItem value="5">5 - Advanced (High technical expertise)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Additional notes about the client's background or preferences"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                {isEditing ? (
                  <>
                    <Button onClick={handleUpdateClient} disabled={!formData.name.trim()}>
                      Update Client
                    </Button>
                    <Button variant="outline" onClick={handleCancelEdit}>
                      Cancel
                    </Button>
                  </>
                ) : (
                  <Button onClick={handleAddClient} disabled={!formData.name.trim()}>
                    Add Client
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Client List */}
          <Card>
            <CardHeader>
              <CardTitle>Existing Clients ({clients.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {clients.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No clients added yet. Add your first client to get started.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {clients.map((client) => (
                    <div key={client.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium">{client.name}</h3>
                          <Badge className={getTechnicalLevelColor(client.technicalKnowledge)}>
                            Level {client.technicalKnowledge} - {getTechnicalLevelText(client.technicalKnowledge)}
                          </Badge>
                        </div>
                        {client.description && <p className="text-sm text-gray-600">{client.description}</p>}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditClient(client)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteClient(client.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Technical Knowledge Guide */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Technical Knowledge Level Guide</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-red-50 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">Beginner (1-2)</h4>
                <p className="text-sm text-red-700">
                  No technical background. Needs simple language, step-by-step instructions, and avoidance of technical
                  jargon.
                </p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">Intermediate (3-4)</h4>
                <p className="text-sm text-yellow-700">
                  Some technical understanding. Can handle moderate technical terms with brief explanations.
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Advanced (5)</h4>
                <p className="text-sm text-green-700">
                  High technical expertise. Comfortable with technical language, APIs, and complex concepts.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
