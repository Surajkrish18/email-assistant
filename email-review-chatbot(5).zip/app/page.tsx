"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Mail, MessageSquare, CheckCircle, Settings } from "lucide-react"
import Link from "next/link"

interface Client {
  id: string
  name: string
  technicalKnowledge: number
  description: string
}

export default function EmailReviewChatbot() {
  const [originalEmail, setOriginalEmail] = useState("")
  const [context, setContext] = useState("")
  const [prompt, setPrompt] = useState("")
  const [selectedClient, setSelectedClient] = useState("default")
  const [clients, setClients] = useState<Client[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState("")

  // Load clients from localStorage on component mount
  useEffect(() => {
    const savedClients = localStorage.getItem("emailReviewClients")
    if (savedClients) {
      setClients(JSON.parse(savedClients))
    }
  }, [])

  const handleReviewEmail = async () => {
    if (!originalEmail.trim() || !prompt.trim()) return

    // Clear previous result
    setResult("")
    setIsAnalyzing(true)

    try {
      const selectedClientData = clients.find((client) => client.id === selectedClient)

      console.log("Sending request with:", {
        originalEmail: originalEmail.substring(0, 100) + "...",
        context,
        prompt,
        client: selectedClientData?.name || "No client",
      })

      const response = await fetch("/api/review-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          originalEmail,
          context,
          prompt,
          client: selectedClientData,
        }),
      })

      console.log("Response status:", response.status)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("API Error:", errorText)
        throw new Error(`API Error: ${response.status} - ${errorText}`)
      }

      const reader = response.body?.getReader()
      if (!reader) throw new Error("No response body")

      let accumulatedResult = ""

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = new TextDecoder().decode(value)
        console.log("Received chunk:", chunk)

        // Parse the AI SDK streaming format
        const lines = chunk.split("\n")
        for (const line of lines) {
          if (line.trim() === "") continue

          // Handle different line formats
          if (line.startsWith("0:")) {
            // Extract the JSON string after "0:"
            const jsonStr = line.slice(2)
            try {
              // The content is just a string, not JSON in this case
              const textContent = JSON.parse(jsonStr)
              accumulatedResult += textContent
              setResult(accumulatedResult)
            } catch (e) {
              // If it's not valid JSON, treat it as plain text
              const textContent = jsonStr.replace(/^"|"$/g, "") // Remove surrounding quotes if any
              accumulatedResult += textContent
              setResult(accumulatedResult)
            }
          } else if (line.startsWith("f:")) {
            // Skip metadata lines that start with "f:"
            continue
          }
        }
      }

      if (!accumulatedResult) {
        throw new Error("No content received from API")
      }
    } catch (error) {
      console.error("Error:", error)
      setResult(
        `Error: ${error instanceof Error ? error.message : "Unknown error occurred"}. Please check the console for details.`,
      )
    } finally {
      setIsAnalyzing(false)
    }
  }

  const getTechnicalLevelText = (level: number) => {
    if (level <= 2) return "Beginner (Non-technical)"
    if (level <= 4) return "Intermediate (Some technical knowledge)"
    return "Advanced (High technical expertise)"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Mail className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Email Review Assistant</h1>
            <Link href="/admin" className="ml-4">
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Admin
              </Button>
            </Link>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            AI-powered email redrafting using AWS Bedrock Claude 3 based on your custom prompts and client technical
            knowledge
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Email Input
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="context">Context (Optional)</Label>
                <Input
                  id="context"
                  placeholder="e.g., Customer complaint response, Technical support, Sales inquiry..."
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="client">Client (Optional)</Label>
                <Select value={selectedClient} onValueChange={setSelectedClient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a client to customize technical level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">No specific client</SelectItem>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.name} - {getTechnicalLevelText(client.technicalKnowledge)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedClient !== "default" && (
                  <p className="text-xs text-gray-600 mt-1">
                    {clients.find((c) => c.id === selectedClient)?.description}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="prompt">Instructions for Claude *</Label>
                <Textarea
                  id="prompt"
                  placeholder="Tell Claude what to do with the email (e.g., Make it more professional and empathetic, Simplify technical terms, Add urgency, etc.)"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
              </div>

              <div>
                <Label htmlFor="email">Original Email Draft *</Label>
                <Textarea
                  id="email"
                  placeholder="Paste your email draft here..."
                  value={originalEmail}
                  onChange={(e) => setOriginalEmail(e.target.value)}
                  rows={10}
                  className="resize-none"
                />
              </div>

              <Button
                onClick={handleReviewEmail}
                disabled={!originalEmail.trim() || !prompt.trim() || isAnalyzing}
                className="w-full"
              >
                {isAnalyzing ? "Redrafting..." : "Redraft Email"}
              </Button>
            </CardContent>
          </Card>

          {/* Results Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                Redrafted Email
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!result && !isAnalyzing ? (
                <div className="text-center py-12 text-gray-500">
                  <Mail className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Enter your email draft, instructions, and click "Redraft Email" to get started</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {result && (
                    <div className="bg-white p-4 rounded-lg border">
                      <div className="whitespace-pre-wrap text-sm leading-relaxed">{result}</div>
                    </div>
                  )}

                  {isAnalyzing && (
                    <div className="flex items-center gap-2 text-blue-600">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                      <span>Redrafting your email...</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sample Email Templates */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Sample Email Scenarios</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="complaint" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="complaint">Customer Complaint</TabsTrigger>
                <TabsTrigger value="technical">Technical Support</TabsTrigger>
                <TabsTrigger value="delay">Service Delay</TabsTrigger>
              </TabsList>

              <TabsContent value="complaint" className="mt-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Sample: Customer Complaint Response</h4>
                  <p className="text-sm text-gray-600 mb-2">Click to use this sample:</p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setOriginalEmail(
                        "Hi,\n\nWe got your complaint about the product not working. This happens sometimes with electronics. You can return it if you want or we can try to fix it. Let me know what you decide.\n\nThanks",
                      )
                      setPrompt(
                        "Make this email more empathetic and professional. Show genuine concern for the customer's issue and provide clear next steps with a helpful tone.",
                      )
                    }}
                  >
                    Use This Sample
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="technical" className="mt-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Sample: Technical Support Response</h4>
                  <p className="text-sm text-gray-600 mb-2">Click to use this sample:</p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setOriginalEmail(
                        "Hello,\n\nYour API integration is failing because of authentication errors in the OAuth 2.0 flow. You need to check your client_id and client_secret parameters in the authorization header. Also make sure your redirect_uri matches exactly what's configured in your app settings.\n\nLet me know if this fixes it.",
                      )
                      setPrompt(
                        "Simplify the technical language for a non-technical audience. Provide step-by-step instructions and explain technical terms in simple language.",
                      )
                    }}
                  >
                    Use This Sample
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="delay" className="mt-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Sample: Service Delay Notification</h4>
                  <p className="text-sm text-gray-600 mb-2">Click to use this sample:</p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setOriginalEmail(
                        "Hi,\n\nYour order is delayed. We had some issues with our supplier and it's going to take longer than expected. It should be ready next week sometime. Sorry for the inconvenience.\n\nRegards",
                      )
                      setPrompt(
                        "Make this more professional and apologetic. Provide a specific timeline, explain the situation transparently, and offer compensation or alternatives.",
                      )
                    }}
                  >
                    Use This Sample
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
